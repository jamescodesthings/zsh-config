#!/usr/bin/env zsh

# Aliases
alias zshconfig='subl ~/.custom'
alias zshconfig-ws='ws ~/.custom'
alias asch='alias | grep'

# Shell
alias rst='source ~/.zshrc'
alias cl='clear'
alias oh='open .'
alias flush-dns='sudo killall -HUP mDNSResponder'
alias count='ls -b1 | wc -l' # Count files in current directory
alias cx='chmod +x'
alias j='z'
alias ls='exa'

CHT="${HOME}/.custom/cht.sh"
if is file $CHT; then
  alias cht="${CHT}"
fi

# Applications
if is available webstorm; then
  alias ws='webstorm'
fi

if is available lazygit; then
  alias lg='lazygit'
fi

# AWS SQS Save
SQS_SAVE_SCRIPT="${HOME}/projects/python/sqs-save/sqs-save.zsh"
if is file ${SQS_SAVE_SCRIPT}; then
  alias sqs-save="${SQS_SAVE_SCRIPT}"
fi

# Node
alias npmst='npm start'
alias npmg='npm i -g'
alias npmL0g='npm list -g --depth=0 2>/dev/null'
alias npmL0='npm list --depth=0 2>/dev/null'
alias npmr='npm run'
alias npmD='npm i -D'
alias npmS='npm i -S'
alias npmSE='npm i -E'
alias npmDE='npm i -D -E'
alias npmIY='npm init -y'
alias npmU='npm uninstall -S -D'
alias npmUG='npm uninstall -g'
alias npm-check-update='npx npm-check -u -E'
alias ncu='npm-check-update'

# Git
if is available git; then
  alias gbD='git branch -D'
  alias gm='git merge --no-ff'
  alias gt='git tag'
  alias rls='echo release_$(date -u +"%Y-%m-%d")'
  alias gtmapt='git tag $(rls)'
  alias git-skip='git update-index --skip-worktree'
  alias git-unskip='git update-index --no-skip-worktree'
  alias git-list-skipped='git ls-files -v . | grep ^S'
  alias grhho='git-i-really-fucked-up'

  # When I committed to the wrong branch, but didn't push yet (phew)
  alias git-i-fucked-up='git reset HEAD~1'

  alias gcmm='gcmsg'
fi

# AWS MFA
alias aws-mfa-sandbox='aws-mfa --device arn:aws:iam::246802837414:mfa/jamesm --profile sandbox && export AWS_PROFILE="sandbox"'
alias aws-mfa-dev='aws-mfa --device arn:aws:iam::879195206356:mfa/jamesm --profile dev && export AWS_PROFILE="dev"'
alias aws-mfa-staging='aws-mfa --device arn:aws:iam::447649200633:mfa/jamesm --profile staging && export AWS_PROFILE="staging"'
alias aws-mfa-prod='aws-mfa --device arn:aws:iam::575515639038:mfa/jamesm --profile prod && export AWS_PROFILE="prod"'

# Gron
if is available gron; then
  alias ungron="gron --ungron"
else
  clr_red 'Missing gron'
fi

# Install Google Fonts
# Install Google Fonts
alias install-google-fonts="curl https://raw.githubusercontent.com/qrpike/Web-Font-Load/master/install.sh | bash"
alias uninstall-google-fonts="curl https://raw.githubusercontent.com/qrpike/Web-Font-Load/master/uninstall.sh | bash"

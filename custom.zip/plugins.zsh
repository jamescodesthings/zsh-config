#!/usr/bin/env zsh

# Make it 1 to log the script output
export ZINIT_DEBUG=0
# Change zinit load method
export LOAD_METHOD='light'

zload 0a blockf atpull"zinit creinstall -q ." zsh-users/zsh-completions

if ! zisloaded zsh-autosuggestions; then
  ZSH_AUTOSUGGEST_USE_ASYNC=1
  ZSH_AUTOSUGGEST_STRATEGY=(history completion)

  zload 0a atload"_zsh_autosuggest_start" zsh-users/zsh-autosuggestions
fi

if ! zisloaded fast-syntax-highlighting; then
  zload 0a atinit"zpcompinit; zpcdreplay" zdharma/fast-syntax-highlighting
fi

zload zsh-users/zsh-history-substring-search
bindkey '^[[A' history-substring-search-up
bindkey '^[[B' history-substring-search-down


zload 0a djui/alias-tips

zload snippet OMZ::/plugins/common-aliases/common-aliases.plugin.zsh
zload 0b DarrinTisdale/zsh-aliases-exa
zload 0b hlissner/zsh-autopair
# zload 0a srijanshetty/zsh-suffix-alias
zload 0c MichaelAquilina/zsh-auto-notify
zload 0c qoomon/zsh-lazyload
zload MikeDacre/careful_rm
if is not file ${HOME}/.rm_recycle; then
  touch ${HOME}/.rm_recycle
fi
zload 0a hcgraf/zsh-sudo
zload snippet OMZ::plugins/colored-man-pages/colored-man-pages.plugin.zsh
zload snippet OMZ::lib/history.zsh
zload snippet OMZ::lib/directories.zsh
zload 0a rupa/z
zload snippet OMZ::plugins/extract/extract.plugin.zsh
zload snippet OMZ::lib/git.zsh
zload snippet OMZ::plugins/git/git.plugin.zsh
zload 0c unixorn/git-extra-commands
zload 0c wfxr/forgit
zload 0c paulirish/git-open
zload mafredri/zsh-async
zinit ice pick'spaceship.zsh' compile'{lib/*,sections/*,tests/*.zsh}' atinit='export SPACESHIP_ROOT=$(pwd)'
zload maximbaz/spaceship-prompt


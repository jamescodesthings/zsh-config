#!/usr/bin/env zsh


export ZINIT_DIR="$HOME/.zinit"
export ZINIT_URL="https://raw.githubusercontent.com/zdharma/zinit/master/doc/install.sh"
export LOAD_METHOD="light"

if is not directory "$ZINIT_DIR"; then
  clr_cyan 'Installing zinit'
  mkdir -p $HOME/.zinit
  sh -c "$(curl -fsSL $ZINIT_URL)"
fi

source "$ZINIT_DIR/bin/zinit.zsh"
autoload -Uz _zinit
(( ${+_comps} )) && _comps[zinit]=_zinit

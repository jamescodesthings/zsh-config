#!/usr/bin/env zsh

# Load Custom Functions and Completions
# fpath=(~/.custom/functions $fpath)

# Put Brew paths first
export PATH="/usr/local/bin:${PATH}"

# Add .NET Core SDK tools
export PATH="$PATH:/Users/jamesmacmillan/.dotnet/tools"

# Projects Directory
export PROJECTS="$HOME/projects"

# PIPENV: Use Local directory
export PIPENV_VENV_IN_PROJECT=1

# Spaceship prompt theme root, for mackup portability
#export SPACESHIP_ROOT="$ZSH/custom/themes/spaceship-prompt"
# SPACESHIP_PROMPT_ORDER=(
#   time          # Time stampts section
#   user          # Username section
#   dir           # Current directory section
#   host          # Hostname section
#   git_branch    # Git branch
#   git_status    # Git status
#   hg            # Mercurial section (hg_branch  + hg_status)
#   package       # Package version
#   node          # Node.js section
#   ruby          # Ruby section
#   elixir        # Elixir section
#   xcode         # Xcode section
#   swift         # Swift section
#   golang        # Go section
#   php           # PHP section
#   rust          # Rust section
#   haskell       # Haskell Stack section
#   julia         # Julia section
#   docker        # Docker section
#   aws           # Amazon Web Services section
#   azure         # Microsof Azure section
#   venv          # virtualenv section
#   conda         # conda virtualenv section
#   pyenv         # Pyenv section
#   dotnet        # .NET section
#   ember         # Ember.js section
#   kubecontext   # Kubectl context section
#   tox           # Tox section
#   exec_time     # Execution time
#   line_sep      # Line break
#   battery       # Battery level and status
#   vi_mode       # Vi-mode indicator
#   jobs          # Background jobs indicator
#   exit_code     # Exit code section
#   char          # Prompt character
# )
# SPACESHIP_RPROMPT_ORDER=(
#   package
#   node
# )
export SPACESHIP_AWS_SYMBOL="☁️  "
export SPACESHIP_DIR_TRUNC=0 # Default is 3

if is-iterm; then
  export SPACESHIP_PROMPT_ADD_NEWLINE=false
  export SPACESHIP_CHAR_SYMBOL="> "
fi

# Set the editor to sublime
if is available subl; then
  export EDITOR='subl -w'
else
  echo 'Install sublime and command subl'
fi

# GO Home
export GOPATH="${HOME}/.go"
# If this ends up changing check it again with $(brew --prefix golang)
export GOROOT="/usr/local/opt/go/libexec"
export PATH="$PATH:${GOPATH}/bin:${GOROOT}/bin"

# Android Home for Android studio
# /Users/james/Library/Android/sdk
export ANDROID_HOME=$HOME/Library/Android/sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/tools
export PATH=$PATH:$ANDROID_HOME/tools/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools

# Postgres config for local testing in docker
export testDbUser=postgres
export testDbPass=testPassword
export testDbHost=localhost
export testDbName=postgres
export DB_NAME=testDb
export DB_USER=testName
export DB_PASSWORD=testPass
export DB_HOST=localhost

# Disable brew auto update
export HOMEBREW_NO_AUTO_UPDATE=1

# If SSH Agent is already running, do not run.
if [[ -z "$SSH_AGENT_PID" ]]
then
  # Do something knowing the pid exists, i.e. the process with $PID is running
  # SSH Agent
  eval "$(ssh-agent -s)" &>/dev/null
fi

# Python scripts / custom global scripts
# export PATH="$PROJECTS/path:${PATH}"
export NVM_DIR="$HOME/.nvm"

export AUTO_NOTIFY_EXPIRE_TIME=20000
export AUTO_NOTIFY_IGNORE=(
  "docker-compose"
  "fzf"
  "ntl"
  "npmst"
  "nodemon"
)

source $HOME/.cargo/env
